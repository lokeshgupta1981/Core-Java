import {NgModule} from "@angular/core";
import { CommonModule } from '@angular/common';
import {
  MatButtonModule, MatCardModule, MatDialogModule, MatInputModule, MatTableModule,
  MatToolbarModule, MatMenuModule,MatIconModule, MatProgressSpinnerModule, MatFormFieldModule, MatDatepicker, MatDatepickerModule, MatNativeDateModule, MatRadioButton, MatRadioModule
} from '@angular/material';
import { FormsModule } from '@angular/forms';
@NgModule({
  imports: [
  CommonModule, 
  MatToolbarModule,
  MatButtonModule, 
  MatCardModule,
  MatInputModule,
  MatDialogModule,
  MatTableModule,
  MatMenuModule,
  MatIconModule,
  MatProgressSpinnerModule, 
  MatDatepickerModule,
  MatNativeDateModule,
  MatFormFieldModule, 
  FormsModule,
  MatRadioModule
  ],
  exports: [
  CommonModule,
   MatToolbarModule, 
   MatButtonModule, 
   MatCardModule, 
   MatInputModule, 
   MatDialogModule, 
   MatTableModule, 
   MatMenuModule,
   MatIconModule,
   MatProgressSpinnerModule,
   MatFormFieldModule,
   MatDatepickerModule,
   MatNativeDateModule,
   FormsModule,
   MatRadioModule
   ],
})
export class CustomMaterialModule { }