import { MenuItem } from './menu.item';
export class Menu {
    items: MenuItem[];

    constructor() {
        this.items = [
            new MenuItem('Login', 'pi pi-fw pi-play', 'login'), 
            new MenuItem('Register', 'pi pi-fw pi-user-plus', 'register'),
            new MenuItem('Logout', 'pi pi-fw pi-power-off', 'logout')
        ];
    }

    getMenuItems():MenuItem[] {
        return this.items;
    }
}